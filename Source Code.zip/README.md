Nots and Crosses
